package com.api;

import com.altimetrik.core.cucumber.CucumberBaseTest;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        features = {"./src/test/resources/features"},
        tags = "@api",
        glue = "com.api"
)
public class CucumberRunner extends CucumberBaseTest {

}
