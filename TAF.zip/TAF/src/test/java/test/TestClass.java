package test;
import com.google.common.collect.Lists;
import java.util.List;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
public class TestClass {
    public static void main(String[] args) {
        List<Integer> list = Lists.newArrayList(1,2,3,4,5,6,7,8);
        List<List<Integer>> subSets = Lists.partition(list, 4);
        System.out.println(subSets);
        List<Integer> lastPartition = subSets.get(1);
        List<Integer> expectedLastPartition = Lists.<Integer> newArrayList(5,6,7, 8);
        assertThat(subSets.size(), equalTo(2));
        assertThat(lastPartition, equalTo(expectedLastPartition));
        System.out.println(expectedLastPartition);
        System.out.println(subSets);
    }
}
