package com.altimetrik.core.config;

import java.util.LinkedList;

public class LinkedListExample {

    public static void main(String[] args) {

        LinkedList linkedList = new LinkedList<>();

        linkedList.add(34);
        linkedList.add(44);
        linkedList.add(54);
        linkedList.forEach(System.out::println);

        System.out.println("*********** LinkedList ******");

        linkedList.descendingIterator().forEachRemaining(System.out::println);
        System.out.println(linkedList.get(1));
        boolean result = checkPalindrome("MadaM");
        System.out.println(result);

    }

    static boolean checkPalindrome(String input) {
        boolean result = true;
        int length = input.length();
        for (int i = 0; i < length/2; i++){
            if (input.charAt(i) != input.charAt(length - i - 1)) {
                result = false;
                break;
            }
    }
    return result;
}
    }



