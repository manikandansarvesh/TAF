/*
package com.altimetrik.core.utils.mobile;


import org.testng.internal.Configuration;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.error.YAMLException;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.MissingResourceException;
import java.util.Properties;


public enum Config {
    INSTANCE;

    Configuration configuration;

    private Config() {
        try {
            Yaml configFile = new org.yaml.snakeyaml.Yaml();
            String yamlFileLocation = this.getConfigFileLocation(this.loadCommandLineArguments());
            if (yamlFileLocation.length() < 1) {
                yamlFileLocation = "";
            }
            this.configuration=(Configuration) configFile.loadAs(new FileReader(yamlFileLocation),Configuration.class);

        } catch (IOException  |YAMLException var5) {
            System.err.println("The  configuration file is not found in src/main/resources or Boolean values might be null in" +var5);
           // RecordKeeper.printErrorLog("The configuration file is not found in src/main/resources",this.getClass());
            throw new MissingResourceException("The configuration file is not found in src/main/resources or Boolean values might be null in YAML",this.getClass());

        }
    }

    private String getConfigFileLocation(Properties properties){
        String configFileName=

    }
}*/
