package com.altimetrik.core.cucumber.reporter.pojo;

import java.util.HashMap;
import java.util.Map;

public class Solution {
    public static void main(String[] args) {
        String input ="Welcome to Java Welcome to Altimetrik";
        String [] result=input.split(" ");
       /* int count =0;
        for(int i=0;i<result.length;i++){
            for(int j=1;j<result.length;j++){
                if(result[i]==result[j]){
                    count++;

                    System.out.print("The result is" +result[i]);
                }
            }*/

        int count =0;
        Map<String,Integer> resultMap=new HashMap<>();
        for(String s:result){
            if(resultMap.containsKey(s)){
                resultMap.put(s,resultMap.get(s+1)) ;
            }
        }
        }
    }


