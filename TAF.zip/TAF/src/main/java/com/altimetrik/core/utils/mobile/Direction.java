package com.altimetrik.core.utils.mobile;

public enum Direction {
    UP("up"),
    DOWN("down"),
    LEFT("left"),
    RIGHT("right"),
    BOTTOM("bottom");

    private final String direction;

    Direction(String direction) {
        this.direction = direction;

    }

    @Override
    public String toString() {
        return direction;
    }
}

