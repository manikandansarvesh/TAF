package com.altimetrik.core.config;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DataComparsion {
    public static void main(String[] args) throws ParseException {

        //20210610
        //21161

        SimpleDateFormat format1 = new SimpleDateFormat("yyDDD");
        SimpleDateFormat format2 = new SimpleDateFormat("yyyyMMdd");

        String oldDate = "21161";
        Date d = format1.parse(oldDate);
        String newDate = format2.format(d);

        System.out.println(newDate);



    }
}
