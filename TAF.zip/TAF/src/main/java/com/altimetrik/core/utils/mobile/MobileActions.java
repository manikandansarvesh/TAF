
package com.altimetrik.core.utils.mobile;

import com.altimetrik.core.config.ConfigProperties;
import com.altimetrik.core.driver.Driver;
import com.altimetrik.core.utils.web.WebActions;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSTouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import java.io.StringReader;
import java.time.Duration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletionException;
import java.util.concurrent.atomic.AtomicInteger;



public class MobileActions extends WebActions {
    private static final Duration SCROLL_DUR = Duration.ofMillis(1000);
    private static final double SCROLL_RATIO = 0.8;
    private final static Logger logger = LogManager.getLogger();
    private final static AtomicInteger counter = new AtomicInteger();
    private static int ANDROID_SCROLL_DIVISOR = 3;
    protected AppiumDriver<?> driver;
    private WebDriverWait wait;
    private int timeout = ConfigProperties.WAIT_TIMEOUT.getInt();
    private Dimension windowSize;

    public MobileActions() {

        driver = Driver.getAppiumDriver();
        wait = new WebDriverWait(driver, timeout);
    }

    public static String getElementStringFromPageSource(String pageSource, String elementxpath, String attribute) {
        String elementToReturn = "";
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = factory.newDocumentBuilder();
            Document doc = documentBuilder.parse(new InputSource(new StringReader(pageSource)));
            XPathFactory xPathFactory = XPathFactory.newInstance();
            XPath xpath = xPathFactory.newXPath();
            Object result = xpath.evaluate(elementxpath, doc, XPathConstants.NODESET);
            NodeList nodes = (NodeList) result;
            for (int i = 0; i < nodes.getLength(); i++) {
                Node currentItem = nodes.item(i);
                elementToReturn = currentItem.getAttributes().getNamedItem(attribute).getNodeValue();
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return elementToReturn;
    }

 /*   public static boolean swipeuntilDynamicElementFound(Direction direction, String dynamicElement, int rounds, boolean clickYorN) {

        Preconditions.checkArgument(dynamicElement.length() > 0, "Dynamic element cannot be btank!");
        Preconditions.checkArgument(rounds > 0, "Rounds cannot be negative!");
        // Recordkeeper.printInfoLog(String.format("Swiping %s to find dynamic element %s...", direction.toString(), dynamicElement), CommonLibrary.class); 126
        //BaseCollection driver = (BaseCollection) DriverManager.getDriverInstance(); 127
        int count = 0;
        boolean found = false;
        while (!found && count <= rounds) {
            try {
                found = Driver.getAppiumDriver().getDynamicElement(dynamicElement).isDisplayed();
                if (found) {
                    Recordkeeper.printInfoLog(String.format("The dynamic element %s was found after %s swipe(s)", dynamicElement, count), MobileActions.class);
                    if (clickYorN)
                        Driver.getAppiumDriver().getDynamicElement(dynamicElement).click();
                    return true;
                } else {
                    Recordkeeper.printInfoLog(String.format("The dynamic element %s was not found after %s swipe(s)", dynamicElement, count), MobileActions.class);
                    count++;
                    swipeInDirection(direction);
                }
            } catch (Exception exception) {
                Recordkeeper.printDebuglog("Exception has been thrown.\n" + "Error info - " + exception + "\n", MobileActions.class);
                count++;
                swipeInDirection(direction);
                if (count >= rounds) {
                    if (Config.INSTANCE.getConfigFile().isTakeScreenShotOnFailure()) {

                    }
                    Recordkeeper.printInfoLog(String.format("The dynamic element %s was not found after %s swipe(s)", dynamicElement, rounds), MobileActions.class);

                }
                return false;
            }
        }
    }

    public static void swipeInDirection(Direction direction) {

        try {
            Dimension size = Driver.getAppiumDriver().manage().window().getSize();
            int startX = size.width;
            int endX = startX;
            int startY = size.height;
            int endY = startY;
            PointOption startPoint = new PointOption();
            PointOption endPoint = new PointOption();
            RecordKeeper.printInfoLog(String.format("Swiping %s...", direction.toString()), MobileActions.class);

            switch (direction) {
                case UP:
                    startPoint.withCoordinates((int) (startX * 0.5), (int) (startY * 0.75));
                    endPoint.withCoordinates((int) (endX * 0.5), (int) (endY * 0.25));
                    if (Driver.getAppiumDriver() instanceof AndroidDriver) {
                        TouchAction action = createTouchAction();
                        action.press(startPoint).waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000))).
                                moveTo(endPoint).release().perform();
                    } else if (Driver.getAppiumDriver() instanceof IOSDriver) {

                        IOSTouchAction action = (IOSTouchAction) createTouchAction();
                        action.press(startPoint).waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000))).
                                moveTo(endPoint).release().perform();
                    }
                    break;
                case DOWN:
                    startPoint.withCoordinates((int) (startX * 0.5), (int) (startY * 0.25));
                    endPoint.withCoordinates((int) (endX * 0.5), (int) (endY * 0.75));
                    if (Driver.getAppiumDriver() instanceof AndroidDriver) {
                        TouchAction action = createTouchAction();
                        action.press(startPoint).waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000))).
                                moveTo(endPoint).release().perform();
                    } else if (Driver.getAppiumDriver() instanceof IOSDriver) {

                        IOSTouchAction action = (IOSTouchAction) createTouchAction();
                        action.press(startPoint).waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000))).
                                moveTo(endPoint).release().perform();
                    }
                    break;
                case RIGHT:
                    startPoint.withCoordinates((int) (startX * 0.25), (int) (startY * 0.5));
                    endPoint.withCoordinates((int) (endX * 0.75), (int) (endY * 0.5));
                    if (Driver.getAppiumDriver() instanceof AndroidDriver) {
                        TouchAction action = new TouchAction(Driver.getAppiumDriver());
                        action.press(startPoint).waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000))).
                                moveTo(endPoint).release().perform();
                    } else if (Driver.getAppiumDriver() instanceof IOSDriver) {
                        TouchAction action = new TouchAction(Driver.getAppiumDriver());
                        action.press(startPoint).waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000))).
                                moveTo(endPoint).release().perform();
                    }
                    break;
                case LEFT:
                    startPoint.withCoordinates((int) (startX * 0.90), (int) (startY * 0.5));
                    endPoint.withCoordinates((int) (endX * 0.10), (int) (endY * 0.5));
                    if (Driver.getAppiumDriver() instanceof AndroidDriver) {
                        TouchAction action = new TouchAction(Driver.getAppiumDriver());
                        action.press(startPoint).waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000))).
                                moveTo(endPoint).release().perform();
                    } else if (Driver.getAppiumDriver() instanceof IOSDriver) {
                        TouchAction action = new TouchAction(Driver.getAppiumDriver());
                        action.press(startPoint).waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000))).
                                moveTo(endPoint).release().perform();
                    }
                    break;
            }
        } catch (WebDriverException ex) {
            throw new CompletionException("Unable to Swipe!!", ex);

        }
    }

    private Dimension getWindowSize() {
        if (windowSize == null) {
            windowSize = driver.manage().window().getSize();
        }
        return windowSize;
    }

    protected void swipe(Point start, Point end, Duration duration) {

        boolean isAndroid = driver instanceof AndroidDriver<?>;
        PointerInput input = new PointerInput(PointerInput.Kind.TOUCH, "finger1");
        Sequence swipe = new Sequence(input, 0);
        swipe.addAction(input.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), start.x, start.y));
        swipe.addAction(input.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
        if (isAndroid) {
            duration = duration.dividedBy(ANDROID_SCROLL_DIVISOR);
        } else {
            swipe.addAction(new Pause(input, duration));
            duration = Duration.ZERO;
        }
        swipe.addAction(input.createPointerMove(duration, PointerInput.Origin.viewport(), end.x, end.y));
        swipe.addAction(input.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
        driver.perform(ImmutableList.of(swipe));
    }

    protected void swipe(double startXPct, double startYPct, double endXPct, double endYPct, Duration duration) {
        Dimension size = getWindowSize();
        Point start = new Point((int) (size.width * startXPct), (int) (size.height * startYPct));
        Point end = new Point((int) (size.width * endXPct), (int) (size.height * endYPct));
        swipe(start, end, duration);
    }

    protected void scroll(ScrollDirection dir, double distance) {
        if (distance < 0 || distance > 1) {
            throw new Error("Scroll distance must be between 0 and 1");
        }
        Dimension size = getWindowSize();
        Point midPoint = new Point((int) (size.width * 0.5), (int) (size.height * 0.5));
        int top = midPoint.y - (int) ((size.height * distance) * 0.5);
        int bottom = midPoint.y + (int) ((size.height * distance) * 0.5);
        int left = midPoint.x - (int) ((size.width * distance) * 0.5);
        int right = midPoint.x + (int) ((size.width * distance) * 0.5);
        if (dir == ScrollDirection.UP) {
            swipe(new Point(midPoint.x, top), new Point(midPoint.x, bottom), SCROLL_DUR);
        } else if (dir == ScrollDirection.DOWN) {
            swipe(new Point(midPoint.x, bottom), new Point(midPoint.x, top), SCROLL_DUR);
        } else if (dir == LEFT) {
            swipe(new Point(left, midPoint.y), new Point(right, midPoint.y), SCROLL_DUR);
        } else {
            swipe(new Point(right, midPoint.y), new Point(left, midPoint.y), SCROLL_DUR);
        }
    }

    protected void scroll(ScrollDirection dir) {
        scroll(dir, SCROLL_RATIO);
    }

    protected void scroll() {
        scroll(ScrollDirection.DOWN, SCROLL_RATIO);
    }

    public void swipeToText(MatchStrategy strategy, String text) {
        switch (strategy) {
            case EXACT:
                try {
                    driver.findElement(MobileBy
                            .AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0))"
                                    + ".scrollIntoView(new UiSelector().text(\"" + text + "\").instance(0))"));
                } catch (NoSuchElementException e) {
                    throw new RuntimeException("Swiping limit is reached. Text: " + text + " not found");
                }
                break;
            case CONTAINS:
                try {
                    driver.findElement(MobileBy
                            .AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0))"
                                    + ".scrollIntoView(new UiSelector().textContains(\"" + text + "\").instance(0))"));
                } catch (NoSuchElementException e) {
                    throw new RuntimeException("Swiping limit is reached. Part text: " + text + " not found");
                }
                break;
            default:
                throw new RuntimeException("Please use correct matching strategy. Available options: 'EXACT' or 'CONTAINS'.");
        }
    }

    public final void waitAndHandleNativeMobileAlertDialog(String buttonToPress, int timeout) {
        Preconditions.checkArgument(buttonToPress.length() > 1, "buttonToPress cannot be empty");
        if (this.driver instanceof IOSDriver) {
            try {
                WebDriverWait waitForElement = new WebDriverWait(this.driver, (long) timeout);
                waitForElement.until(ExpectedConditions.alertIsPresent());
                Map<String, String> args = new HashMap<>();
                args.put("actions", "getButtons");
                List<String> buttons = (List) this.driver.executeScript("mobile:alert", new Object[]{args});
                String buttonLabel = null;
                Iterator var7 = buttons.iterator();
                while (var7.hasNext()) {
                    String button = (String) var7.next();
                    if (button.equals(buttonToPress)) {
                        buttonLabel = button;
                        break;
                    }
                }
                if (buttonLabel == null) {
                    throw new WebDriverException("Unable to find the button that you want to press on tha alert dialog");
                } else {
                    args.put("actions", "accept");
                    args.put("buttonLabel", buttonLabel);
                    this.driver.executeScript("mobile:alert", new Object[]{args});
//                    if(Config.INSTANACE.getConfigFile().isTakeScreenShot()){
//                    this.takeScreenShot();
                    //}
                }
            } catch (Exception ex) {
                //this.logExceptionAndTakeScreenShot(this.driver,var9);
                // throw new CompletionException("Unable to find or handle native mobile alert dialog", var9);

            }
        }*/
/*else{
                throw new UnsupportedOperationException("waitAndHandleNativeMobileAlertDialog only supported on iOS");
            }*//*


    }

    public final void waitAndHandleNativePickerWheel(List<String> pickerFieldsToChoose, String topRightHandButtonLabel, int timeout) {

        Preconditions.checkArgument(pickerFieldsToChoose.size() > 0, "the list of picker fields must be greater than 0");
        if (Driver.getAppiumDriver() instanceof IOSDriver) {
            try {
                WebDriverWait waitForElement = new WebDriverWait(Driver.getAppiumDriver(), (long) timeout);
                String currentContext = Driver.getAppiumDriver().getContext();
                driver.context("NATIVE APP");
                List<WebElement> pickerEls = (List) waitForElement.until(ExpectedConditions.presenceOfAllElementsLocatedBy(MobileBy.className("XCUIElementTypePickerWheel")));
                // if (Config.INSTANCE.getConfigfile().isTakeScreenShot() {
                // this.takeScreenshot();
                // }
                Iterator<String> pickerFieldsToChooseItr = pickerFieldsToChoose.iterator();
                Iterator pickerElsItr = pickerEls.iterator();

                while (pickerElsItr.hasNext() && pickerFieldsToChooseItr.hasNext()) {
                    ((WebElement) pickerElsItr.next()).sendKeys(new CharSequence[]{(CharSequence) pickerFieldsToChooseItr.next()});
                    Driver.getAppiumDriver().findElement(By.xpath("//XCUIElementTypeButton[@label='" + topRightHandButtonLabel + "]")).click();
                    Driver.getAppiumDriver().context(currentContext);
                    //if (Config.INSTANCE.getConfigFile().isTakeScreenshot() {
                    //  this.takeScreenshot();
                }
            } catch (WebDriverException var9) {

            }
        }
    }

    public final void setBiometricAuthentication(String idType, boolean match) {
        if (Driver.getAppiumDriver() instanceof AndroidDriver)
        // if (this.isAndroid)//
        {
            throw new IllegalStateException("Only IOS Devices can access this function.");
        } else {
            if (idType.trim().equalsIgnoreCase("touch")) {
                // ((IOSDriver) Driver.getAppiumDriver().performTouchID(match));
            } else {
                if (!idType.trim().equalsIgnoreCase("face")) {
                    throw new IllegalStateException(idType + " ID is not supported");
                }
                JavascriptExecutor js = Driver.getAppiumDriver();
                js.executeScript("mobile: sendBiometricMatch", new Object[]{ImmutableMap.of("type", "faceId", "match", match)});

            }
        }
    }

    public final WebElement getDynamicElement(String objectName) {
        Preconditions.checkArgument(objectName.length() > 0, "Object Name cannot be blank!");
        try {
            WebElement webElementToReturn = Driver.getAppiumDriver().findElement(this.getFindByMethod(objectName));
            Preconditions.checkNotNull(webElementToReturn, "Appium returned a Null WebElement!!!");
            return webElementToReturn;

        } catch (NullPointerException var3) {
            this.logExceptionAndTakeScreenShot(Driver.getAppiumDriver(), var3);
            throw new NullPointerException("Unable to find the Dynamic Element" + objectName);
        } catch (WebDriverException | IndexOutOfBoundsException var4) {
            this.logExceptionAndTakeScreenShot(Driver.getAppiumDriver(), var4);
            throw new CompletionException("Unable to find the dynamic Element" + objectName, var4);
        }

    }

    private By getFindByMethod(String objectIdentity) {
        By findBy;
        if (objectIdentity.startsWith("//") && objectIdentity.startsWith("(")) {
            findBy = By.xpath(objectIdentity);
        } else {
            String[] objectIdentification = objectIdentity.trim().split("", 2);
            if (objectIdentification[0].equals("id")) {
                findBy = By.id(objectIdentification[1]);
            } else if (objectIdentification[0].equalsIgnoreCase("xpath")) {
                findBy = By.xpath(objectIdentification[1]);
            } else if (objectIdentification[0].equalsIgnoreCase("name")) {
                findBy = By.name(objectIdentification[1]);
            } else if (objectIdentification[0].equalsIgnoreCase("className")) {
                findBy = By.className(objectIdentification[1]);
            } else if (objectIdentification[0].equalsIgnoreCase("css")) {
                findBy = By.cssSelector(objectIdentification[1]);
            } else if (objectIdentification[0].equalsIgnoreCase("linkText")) {
                findBy = By.linkText(objectIdentification[1]);
            } else if (objectIdentification[0].equalsIgnoreCase("accessibilityID")) {
                findBy = MobileBy.AccessibilityId(objectIdentification[1]);
            } else if (objectIdentification[0].equalsIgnoreCase("androidUIAutomator")) {
                findBy = MobileBy.AndroidUIAutomator(objectIdentification[1]);
            } else if (objectIdentification[0].equalsIgnoreCase("iosClassChain")) {
                findBy = MobileBy.iOSClassChain(objectIdentification[1]);
            } else if (objectIdentification[0].equalsIgnoreCase("predicate")) {
                findBy = MobileBy.iOSNsPredicateString(objectIdentification[1]);

            } else {
                findBy = By.xpath(objectIdentification[1]);
            }
        }
        return findBy;
    }

    public final void hideOnScreenKeyboard(String topRightHandButtonLabel) {
        try {
            String currentContext = Driver.getAppiumDriver().getContext();
            Driver.getAppiumDriver().context("NATIVE_APP");
            if (Driver.getAppiumDriver() instanceof AndroidDriver) {
                Driver.getAppiumDriver().hideKeyboard();
            } else if (Driver.getAppiumDriver() instanceof IOSDriver) {
                Driver.getAppiumDriver().findElement(By.xpath("//XCUIElementTypeButton[@label ='" + topRightHandButtonLabel + "'"));

            }
            Driver.getAppiumDriver().context(currentContext);
            if (Config.INSTANCE.getConfigFile().isTakeScreenShot()) {
                this.takeScreenShot();

            }


        } catch (WebDriverException var3) {
            this.logExceptionAndTakeScreenShot(Driver.getAppiumDriver(), var3);
            throw new CompletionException("Unable to hide keyBoard" + objectName, var3);
        }

    }

    public final void pressEnter(String element, boolean... takeScreenshot) {
        try {
            String absolutePath = this.getObjLocatorFromProperties(element);
            Driver.getAppiumDriver().findElement(this.getFindByMethod(absolutePath)).sendKeys(new CharSequence[]{Keys.ENTER});
            if (this.getScreenShotValue(takeScreenshot) && Config.Instance.getConfigFile().isTakeScreenShot()){
                this.takeScreenShot();
            }

        } catch (NullPointerException var4) {
            this.logExceptionAndTakeScreenShot(Driver.getAppiumDriver(), var4);
            this.logAndThrowNullPointerException(element, var4);
        } catch (WebDriverException | IndexOutOfBoundsException var5) {
            this.logExceptionAndTakeScreenShot(Driver.getAppiumDriver(), var5);
            throw new CompletionException("Unable to press the Enter Key", var5);
        }

    }

    public final void scroll(Direction direction) {
        //this.appiumNativeCheck();
        JavascriptExecutor js = Driver.getAppiumDriver();
        Preconditions.checkNotNull(direction, "The element cannot be null");
        try {
            if (direction == Direction.UP) {
                js.executeScript("windows.scrollBy(0,-750)", new Object[0]);
            } else if (direction == Direction.DOWN) {
                js.executeScript("windows.scrollBy(0,750)", new Object[0]);
            } else if (direction == Direction.RIGHT) {
                js.executeScript("windows.scrollBy(750,0)", new Object[0]);
            } else if (direction == Direction.LEFT) {
                js.executeScript("windows.scrollBy(0,750)", new Object[0]);
            } else if (direction == Direction.BOTTOM) {
                js.executeScript("windows.scrollBy(0,document.body.scrollHeight)", new Object[0]);
            }

        } catch (Exception ex) {
            this.logExceptionAndTakeScreenShot(Driver.getAppiumDriver(), ex);
            throw new CompletionException("Unable to terminate the Selenium Session", ex);
        }
    }

    private synchronized void logExceptionAndTakeScreenShot(RemoteWebDriver driver, Exception exception) {
        if (Config.Instance.getConfigFile().isTakeScreenShotOnFailure()) {
            this.takeScreenShot();

        }
        //RecordKeeper.
    }

    */
/**
 * Press KeyCode
 *//*

    public final void pressKeyCode(AndroidKey Key) {
        // AndroidDriver driver=new AndroidDriver();
        try {
            if (this.driver instanceof IOSDriver) {
                throw new IllegalStateException("Only Android devices can access this function");
            }
            KeyEvent event = new KeyEvent(Key);
            //((AndroidDriver) Driver.getAppiumDriver().pressKeyCode(event));

            if (Config.INSTANCE.getConfigFile().isTakeScreenShotOnFailure()) {
                this.takeScreenShot();

            }
        } catch (NullPointerException var3) {
            this.logExceptionAndTakeScreenShot(Driver.getAppiumDriver(), var3);
            this.logAndThrowNullPointerException("No Element is required for this function", var3);
        } catch (WebDriverException | IndexOutOfBoundsException var4) {
            this.logExceptionAndTakeScreenShot(Driver.getAppiumDriver(), var4);
            throw new CompletionException("Unable to press the Enter key", var4);
        }

    }

    public final Object executeJavaScript(String javascriptQuery, Object... args) {
        Preconditions.checkArgument(javascriptQuery.length() > 0, "Query must not be empty!");
        JavascriptExecutor js = Driver.getAppiumDriver();
        Object executorInstance = js.executeScript(javascriptQuery, args);
        if (Config.INSTANCE.getConfigFile().isTakeScreenShot()) {
            this.takeScreenShot();

        } else if (Config.INSTANCE.getConfigFile().isTakeScreenShotOnFailure()) {
            this.takeScreenShot();
        }
        return executorInstance;
    }

    public final void waitForElement(String elementName, int timeout, boolean... takeScreenshot) {
        try {
            WebDriverWait waitForElement = new WebDriverWait(Driver.getAppiumDriver(), (long) timeout);
            waitForElement.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(this.getFindByMethod(this.objectRepository.getProperty(elementName))));
            if (this.getScreenshotValue(takeScreenshot) && Config.INSTANCE.getConfigFile().isTakeScreenShot()) {
                this.takeScreenshot();
            }
        } catch (NullPointerException var5) {
            this.logExceptionAndTakeScreenShot(Driver.getAppiumDriver(), var5);
            throw new NullPointerException("Unable to find the element " + elementName + " in the Object Repository ");
        } catch (IndexOutOfBoundsException | WebDriverException var6) {
            RecordKeeper.printErrorLog("Error while waiting for element", this.getClass(), var6);
            throw new WebDriverException("An error occurred while waiting for the element " + var6);
        }
    }

    public final void waitForElementclickable(String elementName, int timeout, boolean... takeScreenshot) {
        try {
            WebDriverWait waitForElement = new WebDriverWait(Driver.getAppiumDriver(), (long) timeout);
            waitForElement.until(ExpectedConditions.elementToBeClickable(this.getFindByMethod(this.objectRepository.getProperty(elementName))));
            if (this.getScreenshotValue(takeScreenshot) && Config.INSTANCE.getConfigFile().isTakeScreenshot()) {
                this.takeScreenshot();

            }
        } catch (Exception var3) {

        }

    }

    public void deleteCookieNamed(String cookieName) {
        Driver.getAppiumDriver().manage().deleteCookieNamed(cookieName);

    }

    private boolean getScreenShotValue(boolean... takeScreenShot) {
        return takeScreenShot != null && takeScreenShot.length != 0 ? takeScreenShot[0] : false;
    }

    public Actions getActions() {
        try {
            return new Actions(Driver.getAppiumDriver());

        } catch (WebDriverException var2) {
            this.logExceptionAndTakeScreenShot(Driver.getAppiumDriver(), var2);
            throw new CompletionException("Unable to retrive the Actions", var2);
        }

    }

    public final TouchAction createTouchAction() {
        Preconditions.checkNotNull(Driver.getAppiumDriver(), "The appium instance is empty!");
        try {
            if () {
                return new TouchAction(Driver.getAppiumDriver());

            } else if (this.isIOS()) {
                return new IOSTouchAction(Driver.getAppiumDriver());
            } else {
                throw new UnsupportedOperationException("Onluy android and ioS DEVICES ARE SUPPORTED!");
            }
        } catch (Exception var2) {
            this.logExceptionAndTakeScreenShot(Driver.getAppiumDriver(), var2);
            throw new CompletionException("Unable to retrive the Actions", var2);
        }
    }

    public enum ScrollDirection {
        UP, DOWN, LEFT, RIGHT
    }

    public enum MatchStrategy {

        EXACT, CONTAINS
    }
}
*/
}









