package com.altimetrik.core.cucumber.reporter.pojo;

public class iSDigit {
    public static void main(String[] args) {


        String input = "222Santhosh777isTechiue888";
        char [] inputArray= input.toCharArray();
        int sum =0;
        for(int i=0;i<inputArray.length;i++) {

            if (Character.isDigit(inputArray[i])) {

                sum = sum + Integer.parseInt(String.valueOf(inputArray[i])); }
        }

        System.out.println(sum);

    }


}
