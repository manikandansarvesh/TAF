import com.altimetrik.core.driver.Driver;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import io.cucumber.java8.Ta;

import java.util.Arrays;
import java.util.Collection;

public class PalindromeExample extends Throwable {

    public static void main(String[] args) {
        String input = "MadaM";
        String result = "";
        String output = "";
        char[] ch = input.toCharArray();

        String input1 = "This is a new day";
        String[] stringArray = input1.split("");
        Arrays.asList(stringArray);

        for (int i = stringArray.length - 1; i >= 0; i--) {

            output = output + stringArray[i];
        }
        System.out.println(output);


        for (int i = ch.length - 1; i >= 0; i--) {

            result = result + ch[i];
        }
        System.out.println(result);

        if (result.equals(input)) {
            System.out.println("The String are Palindrome");
        } else {
            System.out.println("The String are not Palindrome");
        }
    }

    class A {
        void display() {

        }
    }

    class B extends A {
        B() {
            super.display();
        }

    }

    class Outer {

    }

    class Inner {
        Inner inner = new Inner();

    }

    class Employee {
        private int empID;
        private String eName;
        private Address address;

    }

    class Address {

        private int doorNo;
        private String address1;
        private Address city;
    }
}


   /* Collection
            Collections
            AppiumDriver<?> driver = Driver.getAppiumDriver();
            int startX=0.8;
            int startY=0.5;

    int endX=screen.getWidth()/2;
    int endY=screen.getHeight()/2;
            TouchAction  action =new TouchAction(driver);
            action.press(PointOptions.point(startX, startY)).waitAction(WaitOptions(ofMillis(4)))
            .moveTo(PointOptions.point(endX, endY)).release().perform();
}
*/