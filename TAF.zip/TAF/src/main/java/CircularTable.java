import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class CircularTable {
    public static void main(String[] args) {

        char[] ch = {'A', 'B', 'C', 'D', 'E', 'F'};

        int n = ch.length;
        int k = 4;
        for (int i = k; i < n + k; i++) {
            System.out.print(ch[(i % n)] + " ");
        }

/*
        sortLinkedList([1,4,5],[1,3,4],[2,6])
    }

       public void sortLinkedList(List... list){

        int [] input1={1,4,5};
           int [] input2={1,3,4};
           int [] input3={2,6};
           LinkedList output1 = new LinkedList();

         Arrays.asList(input1, input2, input3).addAll(output1);

           Iterable<> iterable=output1.iterator();
           while(iterable.hasNext()){

           }

        }

        for(int i=0;i<n;i++){
            for(int j=1;j<(n-1);j++)

    }*/

    }

}
