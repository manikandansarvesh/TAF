public class LongestPalindrome {

    public boolean isPalindrome(String str, int x, int y) {
        while (x < y) {
            if (str.charAt(x) != str.charAt(y)) {
                return false;
            }
            x = x + 1;
            y = y - 1;
        }
        return true;
    }

    public int minPalPartition(String str, int x, int y) {
        if (x >= y || isPalindrome(str, x, y)) {
            return 0;
        }

        int answer = Integer.MAX_VALUE;
        int count;


        for (int m = x; m < y; m++) {
            count = minPalPartition(str, x, m) + minPalPartition(str, m + 1, y) + 1;

            answer = Math.min(answer, count);
        }
        return answer;
    }



    public static void main(String[] args) {

        String input = "racecarkayakanna";
        int input1 = input.length();
       // input="racecar";
        int minCut =  new LongestPalindrome().minPalPartition(input,0,input1-1);
        System.out.println("For the string '" + input + "' the number of minimum cuts is: " + minCut);
        input = "kayak";

// computing the size of the string
        input1 = input.length();

// invoking the method makeSquare
        minCut =  new LongestPalindrome().minPalPartition(input, 0, input1 - 1);
        System.out.println("For the string '" + input + "' the number of minimum cuts is: " + minCut);
    }
}
